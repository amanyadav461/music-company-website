import React from "react";
import "./Main.css";

export default function MainFeatures(props) {
	return (
		<div className="MainFeatureItem">
			<span className="MainFeature-icons">{props.icon}</span>
			<span className="MainFeature-heading">{props.heading}</span>
			<p className="main-feat-text">{props.description}</p>
		</div>
	);
}
