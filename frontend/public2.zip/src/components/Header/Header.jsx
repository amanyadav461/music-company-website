import React from "react";
import HeaderSlider from "./HeaderSlider";
import "./Header.css";

export default function Header() {
	return (
		<div className="home-container">
			<div className="Header-main">
				<HeaderSlider />
			</div>
		</div>
	);
}
