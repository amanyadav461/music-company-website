import React from "react";
import "./Header.css";

export default function Box() {
	return <div className="Header-box"></div>;
}
