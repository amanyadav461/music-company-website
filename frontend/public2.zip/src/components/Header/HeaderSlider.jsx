import React from "react";
import Slider from "react-slick";
import HeaderSliderItems from "./HeaderSliderItems";

export default function HeaderSlider() {
	const settings = {
		dots: true,
		infinite: true,
		speed: 500,
		slidesToShow: 1,
		slidesToScroll: 1,
	};
	return (
		<div>
			<Slider {...settings}>
				<HeaderSliderItems
					heading="Awaaz the largest music theme"
					description="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
					btntext="BUY MUSIC"
				/>
				<HeaderSliderItems
					heading="Awaaz the largest music theme"
					description="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
					btntext="BUY MUSIC"
				/>
				<HeaderSliderItems
					heading="Awaaz the largest music theme"
					description="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
					btntext="BUY MUSIC"
				/>
			</Slider>
		</div>
	);
}
